function love.conf(t)
    t.window.title = "Scape from the Zombie City"
    t.window.icon = "assets/images/icon_window.png"
    t.window.width = 1200
    t.window.height = 675
end